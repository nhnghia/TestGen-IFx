/*
 * TestPurpose.h
 *
 *  Created on: 27 juin 2014
 *      Author: nhnghia
 */

#ifndef TESTPURPOSE_H_
#define TESTPURPOSE_H_

namespace tsp {

class TestPurpose {
public:
	TestPurpose();
	virtual ~TestPurpose();
	/**
	 *
	 * @param filename
	 * @return
	 */
	//bool load(string filename);
};

} /* namespace tsp */

#endif /* TESTPURPOSE_H_ */
