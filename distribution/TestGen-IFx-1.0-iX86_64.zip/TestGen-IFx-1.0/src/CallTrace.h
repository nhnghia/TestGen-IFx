/*
 * CallTrace.h
 *
 *  Created on: 27 juin 2014
 *      Author: nhnghia
 */

#ifndef CALLTRACE_H_
#define CALLTRACE_H_

namespace tsp {

class CallTrace {
public:
	static void print();
};

} /* namespace tsp */

#endif /* CALLTRACE_H_ */
