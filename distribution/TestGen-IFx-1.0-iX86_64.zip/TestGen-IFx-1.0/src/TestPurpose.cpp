/*
 * TestPurpose.cpp
 *
 *  Created on: 27 juin 2014
 *      Author: nhnghia
 */

#include "TestPurpose.h"

namespace tsp {

TestPurpose::TestPurpose() {

}

TestPurpose::~TestPurpose() {
}

} /* namespace tsp */
