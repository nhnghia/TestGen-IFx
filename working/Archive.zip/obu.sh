#!/bin/sh
./run.sh obu dfs 6 obu obu "-p true"